﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DAL;

namespace DAL_Testing
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void PatientRegistration()
        {
            DAL_L dl = new DAL_L();
            int res = dl.registration("Ram123","Ram",DateTime.ParseExact("07-08-1995","dd-MM-yyyy",null),1236547896321478,"Sundar Devi","A+",22,"M",7896541231,9998877456,"abc@gmail.com","New Town, Kolkata",231005,"Kolkata","W.Bengal");
            Assert.AreEqual(res, 1);
        }

        //[TestMethod]
        //public void User_Data_Credentials()
        //{
        //    DAL_L dl = new DAL_L();
        //    int res = dl.login_data("Ram123", "12345");
        //}
    }
}
