﻿using System;
using DAL;
using System.Data;

namespace BL
{
    public class BL_L
    {

        public int registration_BL(string patient_id, string patient_name, DateTime dob, double aadhaar_id, string guardian_name, string blood_group,
            int age, string gender, double phone_number, double emergency_Contact, string email_id, string address, double zipcode, string city, string state)
        {
            DAL_L l = new DAL_L();
            return l.registration(patient_id, patient_name, dob, aadhaar_id, guardian_name, blood_group,
            age, gender, phone_number, emergency_Contact, email_id, address, zipcode, city, state);

        }
        public int update_BL(string patient_id, string patient_name, DateTime dob, double aadhaar_id, string guardian_name, string blood_group,
            int age, string gender, double phone_number, double emergency_Contact, string email_id, string address, double zipcode, string city, string state)
        {
            DAL_L l = new DAL_L();
            return l.update_patient_det(patient_id, patient_name, dob, aadhaar_id, guardian_name, blood_group,
            age, gender, phone_number, emergency_Contact, email_id, address, zipcode, city, state);

        }
        public bool validate_user(string username, string password)
        {
            DAL_L l = new DAL_L();
            DataTable dt = l.login_data(username, password);

            if (dt.Rows.Count > 0)  //if username and password is found
            {
                return true;
            }
            else
            {
                return false;
            }

        }


        public bool delete_patient(string username)
        {
            DAL_L l = new DAL_L();
            int dt = l.delete_patient_DAL(username);

            if (dt > 0)  //if username and password is found
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool delete_doctor(string username)
        {
            DAL_L l = new DAL_L();
            int dt = l.delete_doctor_DAL(username);

            if (dt > 0)  //if username and password is found
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public DataTable display_BL(string patient_id)
        {
            DAL_L l = new DAL_L();

            return l.display_patient_data(patient_id);

        }
        public DataTable display_doctor_BL(string doctor_id)
        {
            DAL_L l = new DAL_L();

            return l.display_doctor_data(doctor_id);

        }

        public DataTable display_appointment_BL(string patient_id, string date)
        {
            DAL_L l = new DAL_L();

            return l.display_appointment(patient_id, date);

        }


        //doctor
        public int doctor_registration_BL(string doctor_id, string doctor_password, string doctor_name, DateTime dob, double aadhaar_id, string blood_group,
        string gender, double phone_number, double emergency_Contact, string email_id, string specialisation, string address, double zipcode, string city, string state, string visiting_hours_start, string visiting_hours_end, int room_no)
        {
            DAL_L l = new DAL_L();
            return l.doctor_registration(doctor_id, doctor_password, doctor_name, dob, aadhaar_id, blood_group,
         gender, phone_number, emergency_Contact, email_id, specialisation, address, zipcode, city, state, visiting_hours_start, visiting_hours_end, room_no);

        }

        public int doctor_update_BL(string doctor_id, string doctor_password, string doctor_name, DateTime dob, double aadhaar_id, string blood_group,
        string gender, double phone_number, double emergency_Contact, string email_id, string specialisation, string address, double zipcode, string city, string state, string visiting_hours_start, string visiting_hours_end, int room_no)
        {
            DAL_L l = new DAL_L();
            return l.doctor_update(doctor_id, doctor_password, doctor_name, dob, aadhaar_id, blood_group,
         gender, phone_number, emergency_Contact, email_id, specialisation, address, zipcode, city, state, visiting_hours_start, visiting_hours_end, room_no);

        }

        public int insert_assign_doctor_BL(string visiting_date, string patient_id, string disease_name, string symptoms_description, string room)
        {
            DAL_L l = new DAL_L();
            return l.insert_assign_doctor(visiting_date, patient_id, disease_name, symptoms_description, room);
        }


        public DataTable assign_disease_BL(string symptom)
        {
            DAL_L l = new DAL_L();

            return l.assign_disease(symptom);

        }
        public DataTable select_doctor_BL(string id)
        {
            DAL_L l = new DAL_L();

            return l.select_doctor(id);

        }

        public DataTable validate_doctor(string username, string password)
        {
            DAL_L l = new DAL_L();
            DataTable dt = l.login_doctor(username, password);

            return dt;

        }


        public DataTable display_medication_BL(string patient_id)
        {
            DAL_L l = new DAL_L();

            return l.display_medication(patient_id);

        }

        public int assign_doctor_medication_BL(string visiting_date, string patient_id, string test_name, string test_time, string test_room)
        {

            DAL_L l = new DAL_L();
            return l.assign_doctor_medication(visiting_date, patient_id, test_name, test_time, test_room);

        }
        public int assign_doctor_medication_medicine_BL(string visiting_date, string patient_id, string medicine_name, int no_of_doses, int no_of_days)
        {

            DAL_L l = new DAL_L();
            return l.assign_doctor_medication_medicine(visiting_date, patient_id, medicine_name, no_of_doses, no_of_days);

        }

    }
}
