﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;
using System.Data;

public partial class Assign_Doctor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string str = Patient_ID_Assign.Text.ToString();
        BL_L b = new BL_L();
        if (b.display_BL(Patient_ID_Assign.Text.ToString()).Rows.Count > 0)
        {
            string symptoms = Symptoms_Assign.SelectedItem.Text.ToString();
            string id = "";
            string disease_name = "";
            string specialization = "";
            DateTime dt = DateTime.ParseExact(Visiting_Date_Assign.Text,"yyyy-MM-dd",null);
            DataTable dtable = b.assign_disease_BL(symptoms);
            foreach(DataRow dr in dtable.Rows)
            {
                    id = dr["doctor_id"].ToString();
                 disease_name=dr["disease_name"].ToString();
                 specialization=dr["specialization"].ToString();
            }
            DataTable dt_doctor = b.select_doctor_BL(id);
            string name = "";
            string room = "";
            string visiting_start = "";
            string visiting_end = "";
            
            foreach (DataRow dr in dt_doctor.Rows)
            {
                name = dr["doctor_name"].ToString();
                room =dr["room_no"].ToString();
                visiting_start =dr["visiting_hours_start"].ToString();
                visiting_end = dr["visiting_hours_end"].ToString();
            }

            int res = b.insert_assign_doctor_BL(dt.ToString("yyyy-MM-dd"), str, disease_name, symptoms, room);
            Session["id"]=id;
            Session["name"] = name;
            Session["stime"] = visiting_start;
            Session["etime"] = visiting_end;
            Session["Visiting_Date"] = Visiting_Date_Assign.Text;
            Response.Redirect("assign_doctor_display.aspx?" + System.Web.HttpUtility.UrlEncode(str));

        }
        else
        {

            Response.Write("<script>alert('ID does not exist')</script>");
            Patient_ID_Assign.Text = "";
            Symptoms_Assign.Text = "";
            Description_Assign.Text = "";
            Visiting_Date_Assign.Text = "";
        }
    }
}