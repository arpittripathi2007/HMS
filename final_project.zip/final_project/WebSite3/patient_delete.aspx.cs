﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;
public partial class patient_delete : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            
                
                string id = patient_id.Text;
                BL_L b = new BL_L();
                bool res = b.delete_patient(id);
                if (res)
                {
                    Response.Write("<script>alert('Patient ' + id + ' deleted ')</script>");
                    Response.Redirect("preg.aspx");
                }
                else
                {
                    Response.Write("<script>alert('ID  ' + id + '  doesn't exist')</script>");
                }
                
            
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}