﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BL;


public partial class display_patient : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            if (!IsPostBack)
            {
                string id = Request.QueryString.ToString();
                //Response.Write(id);

                Label1.Visible = false;
                BL_L b = new BL_L();
                DataTable res = b.display_BL(id);

                foreach (DataRow dr in res.Rows)
                {
                    Label1.Text = dr["patient_id"].ToString();
                    //Label2.Text = dr["patient_name"].ToString();
                    //Label3.Text = dr["dob"].ToString();
                    //Label4.Text = dr["guardian_name"].ToString();
                    //Label5.Text = dr["gender"].ToString();
                    //Label6.Text = dr["aadhaar_id"].ToString();
                    //Label7.Text = dr["email_id"].ToString();
                    //Label8.Text = dr["age"].ToString();
                    //Label9.Text = dr["phone_number"].ToString();
                    //Label10.Text = dr["emergency_Contact"].ToString();
                    //Label11.Text = dr["blood_group"].ToString();
                    //Label12.Text = dr["address"].ToString();
                    //Label13.Text = dr["city"].ToString();
                    //Label14.Text = dr["state"].ToString();
                    //Label15.Text = dr["zipcode"].ToString();

                }
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}