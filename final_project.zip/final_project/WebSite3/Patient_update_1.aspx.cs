﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;

public partial class Patient_update_1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        string str = patient_id.Text.ToString();
        BL_L b=new BL_L();
        if (b.display_BL(patient_id.Text.ToString()).Rows.Count > 0)
        {
            Response.Redirect("Update_patient.aspx?"+System.Web.HttpUtility.UrlEncode(str));
        }
        else
        {
           
            Response.Write("<script>alert('ID does not exist')</script>");
            patient_id.Text = "";
        }
    }
}