﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Blood_Count : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        label_bmi.Visible = false;
        label_MassIndex.Visible = false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

      

                string massIndex = String.Empty;
                double h = Convert.ToDouble(height.Text.ToString());
                double w = Convert.ToDouble(weight.Text.ToString());
                double heightCalc = (h / 100) * (h / 100);
                double bmi = w / heightCalc;
                label_bmi.Visible = true;
                label_MassIndex.Visible = true;
                label_bmi.Text = "BMI  =  " + bmi.ToString("0.00");

                //       BMI Categories: 
                //Underweight = <18.5
                //Normal weight = 18.5–24.9 
                //Overweight = 25–29.9 
                //Obesity = BMI of 30 or greater

                if (bmi <= 18.5)
                {
                    massIndex = "Underweight";
                    label_MassIndex.BackColor = System.Drawing.Color.LightCoral;
                    label_bmi.BackColor = System.Drawing.Color.LightCoral;
                }

                if (bmi > 18.5 && bmi <= 24.9)
                {
                    massIndex = "Normal weight";
                    label_MassIndex.BackColor = System.Drawing.Color.PaleGreen;
                    label_bmi.BackColor = System.Drawing.Color.PaleGreen;
                }
                if (bmi > 25 && bmi <= 29.9)
                {
                    massIndex = "Overweight";
                    label_MassIndex.BackColor = System.Drawing.Color.LightCoral;
                    label_bmi.BackColor = System.Drawing.Color.LightCoral;
                }
                label_MassIndex.Text = "Your Mass Index is " + massIndex;

            
        
        }
}