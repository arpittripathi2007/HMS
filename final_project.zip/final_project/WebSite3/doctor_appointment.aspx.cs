﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class View_Doctor_History : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //string connection = "Data Source=PC190301\\MSSQLSERVER2008;Initial Catalog=hms2;Integrated Security=True";
        //using (SqlConnection con = new SqlConnection(connection))
        //{
        //    con.Open();
        //    SqlCommand cmd = new SqlCommand(" select * from appointment_view order by doctor_id;", con);
        //    SqlDataAdapter da = new SqlDataAdapter(cmd);
        //    DataTable dt = new DataTable();
        //    da.Fill(dt);
        //    int i = 3;
        //    int j = 30;
        //    foreach (DataRow dr in dt.Rows)
        //    {
        //        string str = "label" + i;
        //        string str1 = "Label" + j;
        //        Label l1 = new Label();
        //        l1.ID = str;

        //        Label l2 = new Label();
        //        l2.ID = str1;

        //        l1.Text = dr["doctor_id"].ToString();
        //        l2.Text = dr["total_count"].ToString();
        //        i++;
        //        j--;

        //    }
        //}
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
}