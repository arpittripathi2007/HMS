﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class appointment_report : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string patient_id=Session["patient_id"].ToString();
            string doctor=Session["doctor_id"].ToString();
            Label1.Text = patient_id;
            Label2.Text = doctor;
            Label2.Visible = false;
            Label1.Visible = false;
    }
}