﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BMI_Calculator : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        Label_RBC.Visible = false;
        Label_WBC.Visible = false;
        Label_PLATELET.Visible = false;
        Label_ValueRBC.Visible = false;
        Label_ValueWBC.Visible = false;
        Label_ValuePLATELET.Visible = false;

    }
    protected void Submit_Click(object sender, EventArgs e)
    {
        Label_RBC.Visible = true;
        Label_WBC.Visible = true;
        Label_PLATELET.Visible = true;
        Label_ValueRBC.Visible = true;
        Label_ValueWBC.Visible = true;
        Label_ValuePLATELET.Visible = true;

        double rbc_count = Convert.ToDouble(Rbc_TextBox.Text.ToString());
        double wbc_count = Convert.ToDouble(Wbc_TextBox.Text.ToString());
        double platelet_count = Convert.ToDouble(Platelet_TextBox.Text.ToString());

        string str_rbc = String.Empty;
        string str_wbc = String.Empty;
        string str_platelet = String.Empty;

        if (rbc_count < 4.5)
        {
            str_rbc = "Low RBC Count";
            Label_ValueRBC.BackColor = System.Drawing.Color.LightCoral;
            Label_RBC.BackColor = System.Drawing.Color.LightCoral; 
            
        }
        else if (rbc_count >= 4.5 && rbc_count <= 6)
        {
            str_rbc = "Normal RBC Count";
            Label_ValueRBC.BackColor = System.Drawing.Color.PaleGreen; 
            Label_RBC.BackColor = System.Drawing.Color.PaleGreen; 
        }
        else
        {
            str_rbc = "High RBC Count";
            Label_ValueRBC.BackColor = System.Drawing.Color.LightCoral;
            Label_RBC.BackColor = System.Drawing.Color.LightCoral; 
        }

        if (wbc_count < 4.5)
        {
            str_wbc = "Low WBC Count";
            Label_ValueWBC.BackColor = System.Drawing.Color.LightCoral;
            Label_WBC.BackColor = System.Drawing.Color.LightCoral; 
        }
        else if (wbc_count >= 4.5 && rbc_count <= 10.0)
        {
            str_wbc = "Normal WBC Count";
            Label_ValueWBC.BackColor = System.Drawing.Color.PaleGreen; 
            Label_WBC.BackColor = System.Drawing.Color.PaleGreen; 
        }
        else
        {
            str_wbc = "High WBC Count";
            Label_ValueWBC.BackColor = System.Drawing.Color.LightCoral;
            Label_WBC.BackColor = System.Drawing.Color.LightCoral; 
        }
        if (rbc_count < 140)
        {
            str_platelet = "Low PLATELET Count";
            Label_ValuePLATELET.BackColor = System.Drawing.Color.LightCoral;
            Label_PLATELET.BackColor = System.Drawing.Color.LightCoral; 
        }
        else if (platelet_count >= 140 && platelet_count <= 450)
        {
            str_platelet = "Normal PLATELET Count";
            Label_ValuePLATELET.BackColor = System.Drawing.Color.PaleGreen;
            Label_PLATELET.BackColor = System.Drawing.Color.PaleGreen; 
        }
        else
        {
            str_platelet = "High PLATELET Count";
            Label_ValuePLATELET.BackColor = System.Drawing.Color.LightCoral;
            Label_PLATELET.BackColor = System.Drawing.Color.LightCoral;
        }

        Label_ValueRBC.Text = str_rbc;
        Label_ValueWBC.Text = str_wbc;
        Label_ValuePLATELET.Text = str_platelet;

    }
}