﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;
using System.Data;

public partial class User_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LOGIN_BUTTON_Click(object sender, EventArgs e)
    {
        BL_L b = new BL_L();
        string name = "";
        DataTable res = b.validate_doctor(Username.Text,Password.Text);
        foreach (DataRow dr in res.Rows)
        {
             name = dr["doctor_name"].ToString();
        }
       
        if (res.Rows.Count>0)
        {
            Response.Write("<script>alert('Login Suceessful')</script>");
            Response.Redirect("doctor_home_page.aspx?"+ System.Web.HttpUtility.UrlEncode(name));
        }
        else
        {
            Response.Write("<script>alert('Login Failed...Try again')</script>");
            Username.Text = "";
            Password.Text = "";
            Username.Focus(); //write cursor focus automatically on Username TextBox
        }
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("User_Login.aspx");
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Doctor_Login.aspx");
    }
}