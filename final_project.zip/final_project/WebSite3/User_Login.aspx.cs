﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;

public partial class User_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LOGIN_BUTTON_Click(object sender, EventArgs e)
    {
        BL_L b = new BL_L();

        bool res = b.validate_user(Username.Text, Password.Text);
        if (res == true)
        {
            Response.Write("<script>alert('Login Suceessful')</script>");
            Response.Redirect("Homepage.aspx");
        }
        else
        {
            Response.Write("<script>alert('Login Failed...Try again')</script>");
            Username.Text = "";
            Password.Text = "";
            Username.Focus(); //write cursor focus automatically on Username TextBox
        }
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("User_Login.aspx");
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Doctor_Login.aspx");
    }
}