﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BL;

public partial class Prescription_form : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                PATIENT_ID_TEXTBOX.Text= Session["check"].ToString();
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }
    
    protected void submit_Click(object sender, EventArgs e)
    {
         try
        {
            BL_L l = new BL_L();
            string id = PATIENT_ID_TEXTBOX.Text.ToString();
            //BL_L b = new BL_L();
            string visiting_date = visiting_date_TEXTBOX.Text.ToString();
            string medicine_name = MEDICINE_NAME_TEXTBOX.Text.ToString();
            int no_of_doses = Convert.ToInt32(NO_OF_DOSES_TEXTBOX.Text.ToString());
            int no_of_days = Convert.ToInt32(NO_OF_DAYS_TEXTBOX.Text.ToString());
            int result = l.assign_doctor_medication_medicine_BL( visiting_date,  id,  medicine_name,  no_of_doses, no_of_days);

            if (result > 0) //registration is successful
            {
                Response.Write("<script>alert('Data Successfully Entered...for Patient id= " + id + "');window.location.href='Check_patient.aspx'</script>");
               
            }
            else
            {
                Response.Write("<script>alert('Data Could not be Entered Unsuccessful')</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
       
    }
