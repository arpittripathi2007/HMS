﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;
using System.Collections;
using System.Data;
public partial class Doctor_Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
            ArrayList hour = new ArrayList();
            hour.Add("Select...");
            int i;
            for (i = 0; i <= 12; i++)
            {
                hour.Add(i);
            }
            ArrayList minute = new ArrayList();
            int j;
            minute.Add("Select...");
            for (j = 0; j <= 60; j++)
            {
                minute.Add(j);
            }
            ArrayList am_pm = new ArrayList();
            am_pm.Add("Select...");
            am_pm.Add("AM");
            am_pm.Add("PM");

            foreach (var a in hour)
            {
                DropDownList1.Items.Add(a.ToString());
                DropDownList4.Items.Add(a.ToString());
            }
            foreach (var a in minute)
            {
                DropDownList2.Items.Add(a.ToString());
                DropDownList5.Items.Add(a.ToString());
            }

            foreach (var a in am_pm)
            {
                DropDownList3.Items.Add(a.ToString());
                DropDownList6.Items.Add(a.ToString());
            }
            string id = Request.QueryString.ToString();
            BL_L b = new BL_L();
            DataTable res = b.display_doctor_BL(id);
            foreach (DataRow dr in res.Rows)
            {
                Doctor_ID.Text=dr["doctor_id"].ToString();
                Doctor_Name.Text = dr["doctor_password"].ToString();
                Doctor_Password.Text = dr["doctor_name"].ToString();
                dob.Text=dr["dob"].ToString();
                Aadhaar_ID.Text=dr["aadhaar_id"].ToString();
                Blood_Group.Text=dr["blood_group"].ToString();
                Gender.Text=dr["gender"].ToString();
                Phone_Number.Text=dr["phone_number"].ToString();
                Emergency_Contact.Text=dr["emergency_Contact"].ToString();
                Email_ID.Text=dr["email_id"].ToString();
                Specialization.Text=dr["specialisation"].ToString();
                Address.Text=dr["address"].ToString();
                Pincode.Text=dr["zipcode"].ToString();
                City.Text=dr["city"].ToString();
                State.Text = dr["state"].ToString();
                string stime=dr["visiting_hours_start"].ToString();
                string etime=dr["visiting_hours_end"].ToString();
                string[] stime1 = stime.Split(':');
                string[] stime2 = stime1[1].Split(' ');
                string[] etime1 = etime.Split(':');
                string[] etime2 = etime1[1].Split(' ');
                Response.Write(stime1[0]);
                Response.Write(stime2[0]);
                Response.Write(stime2[1]);
                DropDownList1.Text = stime1[0];
                DropDownList2.Text = stime2[0];
                DropDownList3.Text = stime2[1];
                DropDownList4.Text = etime1[0];
                DropDownList5.Text = etime2[0];
                DropDownList6.Text = etime2[1];
                TextBox1.Text=dr["room_no"].ToString();
            }
        }
    }
    
    protected void Button1_Click1(object sender, EventArgs e)
    {
        try
        {              
            string doctor_id = Doctor_ID.Text;
            string doctor_namee = Doctor_Name.Text;
            string doctor_password = Doctor_Password.Text;
            string dob1 = Convert.ToDateTime(dob.Text).ToString("yyyy-MM-dd");
            DateTime date_of_birth = DateTime.ParseExact(dob1,"yyyy-MM-dd",System.Globalization.CultureInfo.InvariantCulture);
            //Response.Write(date_of_birth);
            double aadhaar_id = Convert.ToDouble(Aadhaar_ID.Text);
            string blood_group = Blood_Group.SelectedItem.Text.ToString();
            string gen = Gender.Text;
            double phone_number = Convert.ToDouble(Phone_Number.Text);
            double emergency_Contact = Convert.ToDouble(Emergency_Contact.Text);
            string email_id = Email_ID.Text;
            string specialisation = Specialization.SelectedItem.Text.ToString();
            string address = Address.Text;
            double zipcode = Convert.ToDouble(Pincode.Text);
            string city_nam = City.SelectedItem.Text.ToString();
            string state = State.SelectedItem.Text.ToString(); ;

            string Start_Time = DropDownList1.SelectedItem.Text.ToString() + ":" + DropDownList2.SelectedItem.Text.ToString() + " " + DropDownList3.SelectedItem.Text.ToString(); ;
            string End_Time = DropDownList4.SelectedItem.Text.ToString() + ":" + DropDownList5.SelectedItem.Text.ToString() + " " + DropDownList6.SelectedItem.Text.ToString();
            int room = Convert.ToInt32(TextBox1.Text);

            BL_L b = new BL_L();
            //    int res = b.doctor_registration_BL(doctor_id, doctor_namee, doctor_password, date_of_birth, aadhaar_id, blood_group,
            //gen, phone_number, emergency_Contact, email_id, specialisation, address, zipcode, city_nam, state, stime, etime, room);
            int res = b.doctor_update_BL(doctor_id, doctor_namee, doctor_password, date_of_birth, aadhaar_id, blood_group,
        gen, phone_number, emergency_Contact, email_id, specialisation, address, zipcode, city_nam, state, Start_Time, End_Time, room);

            if (res > 0) //registration is successful
            {
                Response.Write("<script>alert('Update Successful for User id= " + doctor_id + "');window.location.href=update_doctor.aspx</script>");
                //Response.Redirect("Doctor_Registration.aspx");
            }
            else
            {
                Response.Write("<script>alert('Registration Unsuccessful')</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}