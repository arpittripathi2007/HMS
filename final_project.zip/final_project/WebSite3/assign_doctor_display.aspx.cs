﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;
using System.Data;
using System.Data.SqlClient;

public partial class assign_doctor_display : System.Web.UI.Page
{
   public  string connection = "Data Source=PC190301\\MSSQLSERVER2008;Initial Catalog=hms2;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {

        string str = Request.QueryString.ToString();
       string visiting_date=Session["Visiting_Date"].ToString();
       string doctor_id = Session["id"].ToString();
        string doctor_name = Session["name"].ToString();
        string s_time = Session["stime"].ToString();
        string e_time = Session["etime"].ToString();
        BL_L b = new BL_L();
        DataTable res = b.display_appointment_BL(str,visiting_date);




        foreach (DataRow dr in res.Rows)
        {
            Label1.Text = dr["patient_id"].ToString();
           
            
            Label6.Text = dr["room"].ToString();
            Label5.Text = dr["symptoms_description"].ToString();
        }
        Label3.Text = doctor_id;
        Label4.Text = "Dr."+doctor_name;

        Label7.Text = s_time + "-" + e_time;
        using (SqlConnection con = new SqlConnection(connection))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("appointment_reportt", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@patient_id", Label1.Text);
            cmd.Parameters.AddWithValue("@doctor_id", Label3.Text);
            cmd.Parameters.AddWithValue("@doctor_name", Label4.Text);
            cmd.Parameters.AddWithValue("@symptom", Label5.Text);
            cmd.Parameters.AddWithValue("@room", Label6.Text);
            cmd.Parameters.AddWithValue("@timing", Label7.Text.ToString());

            int res2 = cmd.ExecuteNonQuery();
            Session["patient_id"] = Label1.Text;
            Session["doctor_id"] = Label3.Text;
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("appointment_report.aspx");
    }
}