﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;

public partial class Delete_doctor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {


            string id = TextBox1.Text;
            BL_L b = new BL_L();
            bool res = b.delete_doctor(id);
            if (res)
            {
                Response.Write("<script>alert('Doctor " + id + " deleted ');window.location.href='Delete_doctor.aspx'</script>");
               
            }
            else
            {
                Response.Write("<script>alert('ID  ' + id + '  doesn't exist')</script>");
            }


        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}