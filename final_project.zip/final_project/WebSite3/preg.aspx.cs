﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;

public partial class preg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Random rd = new Random();
       string str= rd.Next(100001, 999999).ToString();
       Patient_ID.Text = str;
    }
    protected void Submit_button_Click(object sender, EventArgs e)
    {
        try
        {
            //Registration Code
            //Random rd = new Random();
            string patient_id = Patient_ID.Text;
            string patient_namee = patient_name.Text;

            DateTime date_of_birth = DateTime.ParseExact(dob.Text, "yyyy-MM-dd", null);
            double aadhaar_id = Convert.ToDouble(Aadhaar.Text);
            string guardian_name = Guardian_name.Text;
            string blood_group = Blood_Group.Text;
            int age = Convert.ToInt32(Age.Text);
            string gen = gender.Text;
            double phone_number = Convert.ToDouble(CONTACT_NO.Text);
            double emergency_Contact = Convert.ToDouble(Emergency_Contact.Text);
            string email_id = EMAIL_ID.Text;
            string address = Address.Text;
            double zipcode = Convert.ToDouble(Pincode.Text);
            string city_nam = City_Name.Text ;
            string state = State.Text;
            Session["user_id"] = patient_id;

            BL_L b = new BL_L();
            int res = b.registration_BL(patient_id, patient_namee, date_of_birth , aadhaar_id, guardian_name, blood_group,
            age, gen, phone_number, emergency_Contact, email_id, address, zipcode, city_nam , state);

            if (res > 0) //registration is successful
            {

                Response.Write("<script>alert('Registration Successful...Your User id= " + Patient_ID + "');</script>");
                Response.Redirect("Notification.aspx");
            }
            else
            {
                Response.Write("<script>alert('Registration Unsuccessful')</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}