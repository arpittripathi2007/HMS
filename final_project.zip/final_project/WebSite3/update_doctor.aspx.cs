﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;

public partial class update_doctor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
            
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string str = TextBox1.Text.ToString();
        BL_L b = new BL_L();
        if (b.display_doctor_BL(TextBox1.Text.ToString()).Rows.Count > 0)
        {
            Response.Redirect("Doctor_Registration1.aspx?" + System.Web.HttpUtility.UrlEncode(str));
        }
        else
        {

            Response.Write("<script>alert('ID does not exist')</script>");
            TextBox1.Text = "";
        }
    }
}