﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;

public partial class Patient_Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void pname_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Fname_TextBox_TextChanged(object sender, EventArgs e)
    {

    }
    protected void pid_TextChanged(object sender, EventArgs e)
    {

    }
    protected void ai_TextChanged(object sender, EventArgs e)
    {

    }
    protected void gender_tb_TextChanged(object sender, EventArgs e)
    {

    }
    protected void ei_TextChanged(object sender, EventArgs e)
    {

    }
    protected void cn_TextChanged(object sender, EventArgs e)
    {

    }
    protected void ecn_TextChanged(object sender, EventArgs e)
    {

    }
    protected void dob_tb_TextChanged(object sender, EventArgs e)
    {

    }
    protected void age_tb_TextChanged(object sender, EventArgs e)
    {

    }
    protected void bg_TextChanged(object sender, EventArgs e)
    {

    }
    protected void city_tb_TextChanged(object sender, EventArgs e)
    {

    }
    protected void state_tb_TextChanged(object sender, EventArgs e)
    {

    }
    protected void pincode_tb_TextChanged(object sender, EventArgs e)
    {

    }
    protected void address_tb_TextChanged(object sender, EventArgs e)
    {

    }
    protected void SUBMIT_Click(object sender, EventArgs e)
    {
        //try
        //{
        //    //Registration Code
        //    //Random rd = new Random();
        //    string patient_id = pid.Text;
        //    string patient_name = pname.Text;

        //    DateTime dob = DateTime.ParseExact(dob_tb.Text, "yyyy-MM-dd", null);
        //    double aadhaar_id = Convert.ToDouble(ai.Text);
        //    string guardian_name = gn.Text;
        //    string blood_group = bg.Text;
        //    int age = Convert.ToInt32(age_tb.Text);
        //    string gender = gender_tb.Text;
        //    double phone_number = Convert.ToDouble(cn.Text);
        //    double emergency_Contact = Convert.ToDouble(ecn.Text);
        //    string email_id = ei.Text;
        //    string address = address_tb.Text;
        //    double zipcode = Convert.ToDouble(pincode_tb.Text);
        //    string city = city_tb.Text;
        //    string state = state_tb.Text;


        //    BL_L b = new BL_L();
        //    int res = b.registration_BL(patient_id, patient_name, dob, aadhaar_id, guardian_name, blood_group,
        //    age, gender, phone_number, emergency_Contact, email_id, address, zipcode, city, state);

        //    if (res > 0) //registration is successful
        //    {
        //        Response.Write("<script>alert('Registration Successful...Your User id= " + pid + "');</script>");
        //    }
        //    else
        //    {
        //        Response.Write("<script>alert('Registration Unsuccessful')</script>");
        //    }
        //}
        //catch (Exception ex)
        //{
        //    Response.Write(ex.Message);
        //}
    }
}