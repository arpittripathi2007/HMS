﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Glucose_Reading : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label_Glucose_Result.Visible = false;
    }

    protected void Submit_Click(object sender, EventArgs e)
    {
        int glucose_value = Convert.ToInt32(GlucoseLevel.Text.ToString());
        string Time = TimeOfTheDay.Text.ToString();
        string res = String.Empty;
        Label_Glucose_Result.Visible = true;

        if (Time.Equals("Fasting"))
        {
            if (glucose_value < 70)
            {
                res = "Low Sugar";
                Label_Glucose_Result.BackColor = System.Drawing.Color.LightCoral; 
            }
            else if (glucose_value >= 70 && glucose_value < 110)
            {
                res = "Normal";
                Label_Glucose_Result.BackColor = System.Drawing.Color.PaleGreen; 
            }
            else
            {
                res = "High Sugar";
                Label_Glucose_Result.BackColor = System.Drawing.Color.LightCoral; 
            }
        }
        else
        {
            if (glucose_value < 70)
            {
                res = "Low Sugar";
                Label_Glucose_Result.BackColor = System.Drawing.Color.LightCoral; 
            }
            else if (glucose_value >= 70 && glucose_value < 150)
            {
                res = "Normal";
                Label_Glucose_Result.BackColor = System.Drawing.Color.PaleGreen; 
            }
            else
            {
                res = "High Sugar";
                Label_Glucose_Result.BackColor = System.Drawing.Color.LightCoral; 
            }

        }
        Label_Glucose_Result.Text = res;


    }
}