﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Check_patient : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void Submit_Click(object sender, EventArgs e)
    {
        string patient_id_fetch = patient_id_textBox.Text.ToString();
        Response.Redirect("check_patient_details.aspx?" + System.Web.HttpUtility.UrlEncode(patient_id_fetch));
    }
}