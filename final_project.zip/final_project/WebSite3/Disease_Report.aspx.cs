﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class Disease_Report : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        //        string connection = "Data Source=PC190301\\MSSQLSERVER2008;Initial Catalog=hms2;Integrated Security=True";
        //        using (SqlConnection con = new SqlConnection(connection))
        //        {

        //            //open the connection
        //            con.Open();

        //            //Write SQL Command for Insert
        //            //Call Stored proc for insert
        //            SqlCommand cmd = new SqlCommand("select ds.disease_name,count(distinct(ad.patient_id)) as count_patient from assign_doctor ad join disease_specialization ds on ds.disease_name = ad.disease_name group by ds.disease_name;", con);


        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            DataTable dt = new DataTable();
        //                        da.Fill(dt);


        //    }
        //}
    }
}