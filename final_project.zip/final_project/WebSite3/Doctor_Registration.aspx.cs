﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;
using System.Collections;

public partial class Doctor_Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Random rd = new Random();
            string str = rd.Next(100001, 999999).ToString();
            Doctor_ID.Text = str;
            ArrayList hour = new ArrayList();
            hour.Add("Select...");
            int i;
            for (i = 0; i <= 12; i++)
            {
                hour.Add(i);
            }
            ArrayList minute = new ArrayList();
            int j;
            minute.Add("Select...");
            for (j = 0; j <= 60; j++)
            {
                minute.Add(j);
            }
            ArrayList am_pm = new ArrayList();
            am_pm.Add("Select...");
            am_pm.Add("AM");
            am_pm.Add("PM");

            foreach (var a in hour)
            {
                DropDownList1.Items.Add(a.ToString());
                DropDownList4.Items.Add(a.ToString());
            }
            foreach (var a in minute)
            {
                DropDownList2.Items.Add(a.ToString());
                DropDownList5.Items.Add(a.ToString());
            }

            foreach (var a in am_pm)
            {
                DropDownList3.Items.Add(a.ToString());
                DropDownList6.Items.Add(a.ToString());
            }
        }
    }
    
    protected void Button1_Click1(object sender, EventArgs e)
    {
        try
        {              
            string doctor_id = Doctor_ID.Text;
            string doctor_namee = Doctor_Name.Text;
            string doctor_password = Doctor_Password.Text;
            string dob1 = Convert.ToDateTime(dob.Text).ToString("yyyy-MM-dd");
            DateTime date_of_birth = DateTime.ParseExact(dob1,"yyyy-MM-dd",System.Globalization.CultureInfo.InvariantCulture);
            //Response.Write(date_of_birth);
            double aadhaar_id = Convert.ToDouble(Aadhaar_ID.Text);
            string blood_group = Blood_Group.SelectedItem.Text.ToString();
            string gen = Gender.Text;
            double phone_number = Convert.ToDouble(Phone_Number.Text);
            double emergency_Contact = Convert.ToDouble(Emergency_Contact.Text);
            string email_id = Email_ID.Text;
            string specialisation = Specialization.SelectedItem.Text.ToString();
            string address = Address.Text;
            double zipcode = Convert.ToDouble(Pincode.Text);
            string city_nam = City.SelectedItem.Text.ToString();
            string state = State.SelectedItem.Text.ToString(); ;

            string Start_Time = DropDownList1.SelectedItem.Text.ToString() + ":" + DropDownList2.SelectedItem.Text.ToString() + " " + DropDownList3.SelectedItem.Text.ToString(); ;
            string End_Time = DropDownList4.SelectedItem.Text.ToString() + ":" + DropDownList5.SelectedItem.Text.ToString() + " " + DropDownList6.SelectedItem.Text.ToString();
            int room = Convert.ToInt32(TextBox1.Text);

            BL_L b = new BL_L();
            //    int res = b.doctor_registration_BL(doctor_id, doctor_namee, doctor_password, date_of_birth, aadhaar_id, blood_group,
            //gen, phone_number, emergency_Contact, email_id, specialisation, address, zipcode, city_nam, state, stime, etime, room);
            int res = b.doctor_registration_BL(doctor_id, doctor_namee, doctor_password, date_of_birth, aadhaar_id, blood_group,
        gen, phone_number, emergency_Contact, email_id, specialisation, address, zipcode, city_nam, state, Start_Time, End_Time, room);

            if (res > 0) //registration is successful
            {
                Response.Write("<script>alert('Registration Successful...Your User id= " + doctor_id + "');window.location.href=Doctor_Registration.aspx</script>");
                //Response.Redirect("Doctor_Registration.aspx");
            }
            else
            {
                Response.Write("<script>alert('Registration Unsuccessful')</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}