﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BL;
using System.Data;
public partial class Update_patient : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string str = Request.QueryString.ToString();
            BL_L b = new BL_L();
            DataTable res = b.display_BL(str);

            foreach (DataRow dr in res.Rows)
            {
                pid.Text = dr["patient_id"].ToString();
                pname.Text = dr["patient_name"].ToString();
                DateTime datee = (DateTime)dr["dob"];
                pdob.Text = datee.ToString("yyyy-MM-dd");
                pgname.Text = dr["guardian_name"].ToString();
                pgender.Text = dr["gender"].ToString();
                paadhaar.Text = dr["aadhaar_id"].ToString();
                pemail.Text = dr["email_id"].ToString();
                pagee.Text = dr["age"].ToString();
                pno.Text = dr["phone_number"].ToString();
                peno.Text = dr["emergency_Contact"].ToString();
                pblood_group.Text = dr["blood_group"].ToString();
                paddress.Text = dr["address"].ToString();
                pstate.Text = dr["state"].ToString();
                pcity.Text = dr["city"].ToString();
                ppincode.Text = dr["zipcode"].ToString();
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            //Registration Code
            //Random rd = new Random();
            string patient_id = pid.Text;
            string patient_namee = pname.Text;
            DateTime date_of_birth = DateTime.ParseExact(pdob.Text, "yyyy-MM-dd", null);
            double aadhaar_id = Convert.ToDouble(paadhaar.Text);
            string guardian_name = pgname.Text;
            string blood_group = pblood_group.Text;
            int age = Convert.ToInt32(pagee.Text);
            string gen = pgender.Text;
            double phone_number = Convert.ToDouble(pno.Text);
            double emergency_Contact = Convert.ToDouble(peno.Text);
            string email_id = pemail.Text;
            string address =paddress.Text;
            double zipcode = Convert.ToDouble(ppincode.Text);
            string city_nam = pcity.Text;
            string state = pstate.Text;


            BL_L b = new BL_L();
            int res = b.update_BL(patient_id, patient_namee, date_of_birth, aadhaar_id, guardian_name, blood_group,
            age, gen, phone_number, emergency_Contact, email_id, address, zipcode, city_nam, state);

            if (res > 0) //registration is successful
            {
                Response.Write("<script>alert('Update Successful For User id= " +pid.Text + "');</script>");
                Response.Redirect("preg.aspx");
               
            }
            else
            {
                Response.Write("<script>alert('Updation Unsuccessful')</script>");
                Response.Redirect("preg.aspx");
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}