﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Thyroid_Calculation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label_TSHLevel.Visible = false;
        Label_FT4Level.Visible = false;
        Label_Remark.Visible = false;
        Label_ValueTsh.Visible = false;
        Label_ValueT4.Visible = false;
        Label_ValueRemark.Visible = false;

    }
   
    protected void Submit_Click(object sender, EventArgs e)
    {

        Label_TSHLevel.Visible = true;
        Label_FT4Level.Visible = true;
        Label_Remark.Visible = true;
        Label_ValueTsh.Visible = true;
        Label_ValueT4.Visible = true;
        Label_ValueRemark.Visible = true;



        double tsh = Convert.ToDouble(TSH_TextBox.Text.ToString());
        double ft4 = Convert.ToDouble(T4_TextBox.Text.ToString());

        string str_tsh = String.Empty;
        string str_t4 = String.Empty;
        string remark = String.Empty;

        if (tsh < 0.4)
        {
            str_tsh = "Low";
            Label_TSHLevel.BackColor = System.Drawing.Color.LightCoral;
            Label_ValueTsh.BackColor = System.Drawing.Color.LightCoral;
        }
        if (tsh >= 0.4 && tsh <= 4.0)
        {
            str_tsh = "Normal";
            Label_TSHLevel.BackColor = System.Drawing.Color.PaleGreen;
            Label_ValueTsh.BackColor = System.Drawing.Color.PaleGreen; 
        }
        else
        {
            str_tsh = "High";
            Label_TSHLevel.BackColor = System.Drawing.Color.LightCoral;
            Label_ValueTsh.BackColor = System.Drawing.Color.LightCoral;
           
        }

        if (ft4 < 0.7)
        {
            str_t4 = "Low";
            Label_FT4Level.BackColor = System.Drawing.Color.LightCoral;
            Label_ValueT4.BackColor = System.Drawing.Color.LightCoral;
        }
        if (ft4 >= 0.7 && ft4 <= 1.9)
        {
            str_t4 = "normal";
            Label_FT4Level.BackColor = System.Drawing.Color.PaleGreen;
            Label_ValueT4.BackColor = System.Drawing.Color.PaleGreen;
        }
        else
        {
            str_t4 = "High";
            
            Label_FT4Level.BackColor = System.Drawing.Color.LightCoral;
            Label_ValueT4.BackColor = System.Drawing.Color.LightCoral;
            
        }


        if (str_tsh == "High" && str_t4 == "High")
        {
            remark = "Tumor of pituitary gland";
            Label_Remark.BackColor = System.Drawing.Color.LightCoral;
            Label_ValueRemark.BackColor = System.Drawing.Color.LightCoral;
            
        }
        else if (str_tsh == "High" && str_t4 == "Low")
        {
            remark = "Secondary hypothyroidism";
            Label_Remark.BackColor = System.Drawing.Color.Gold;
            Label_ValueRemark.BackColor = System.Drawing.Color.Gold;
        }

           
        else if (str_tsh == "Low" && str_t4 == "High")
        {
            remark = "Grave’s disease";
            Label_Remark.BackColor = System.Drawing.Color.Gold;
            Label_ValueRemark.BackColor = System.Drawing.Color.Gold;
        }
        else if (str_tsh == "Low" && str_t4 == "Low")
        {
            remark = "Hashimoto’s disease";
            Label_Remark.BackColor = System.Drawing.Color.LightCoral;
            Label_ValueRemark.BackColor = System.Drawing.Color.LightCoral;
        }

        else
        {
            remark = "Your Thryroid is Normal";
            Label_Remark.BackColor = System.Drawing.Color.PaleGreen;
            Label_ValueRemark.BackColor = System.Drawing.Color.PaleGreen;

        }

        Label_ValueTsh.Text = str_tsh;
        Label_ValueT4.Text = str_t4;
        Label_ValueRemark.Text = remark;




    }
}