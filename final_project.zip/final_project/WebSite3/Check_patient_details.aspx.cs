﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BL;

public partial class Check_patient_details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                string id = Request.QueryString.ToString();
                patient_id_textBox.Text = id;
                Session["check"] = id;
                //BL_L b = new BL_L();
                //DataTable res = b.display_BL(id);

                //foreach (DataRow dr in res.Rows)
                //{
                //    patient_id_textBox.Text = dr["patient_id"].ToString();
                //}
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
    protected void Submit_Click(object sender, EventArgs e)
    {
        try
        {
            BL_L l = new BL_L();
            string id = patient_id_textBox.Text.ToString();
            //BL_L b = new BL_L();
            string visiting_date = visiting_date_textBox.Text.ToString();
            string test_name = Test_name_textBox.Text.ToString();
            string test_date = Test_date_textBox.Text.ToString();
            string test_room = Test_room_textBox.Text.ToString();
            int result = l.assign_doctor_medication_BL(visiting_date, id, test_name, test_date, test_room);

            if (result > 0) //registration is successful
            {
                Response.Write("<script>alert('Data Successfully Entered...for Patient id= " + id + "'); window.location.href='check_patient_details.aspx'</script>");
                
            }
            else
            {
                Response.Write("<script>alert('Data Could not be Entered Unsuccessful')</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}