﻿using System;
//Namespace for Ado.Net
using System.Data.SqlClient;
using System.Data;

namespace DAL //Do not remove the namespace
{
    public class DAL_L
    {
        public string connection = "Data Source=PC190301\\MSSQLSERVER2008;Initial Catalog=hms2;Integrated Security=True";

        //INSERT INTO PATIENT(REGISTRATION)
        public int registration(string patient_id, string patient_name, DateTime dob, double aadhaar_id, string guardian_name, string blood_group,
            int age, string gender, double phone_number, double emergency_Contact, string email_id, string address, double zipcode, string city, string state)
        {
            //ADO.NET FOR INSERT
            //(i)connection path to connect with SQL Server
            using (SqlConnection con = new SqlConnection(connection))
            {
                //open the connection
                con.Open();

                //Write SQL Command for Insert
                //Call Stored proc for insert
                SqlCommand cmd = new SqlCommand("insert_data_patient", con);

                //What is insert_data?
                cmd.CommandType = CommandType.StoredProcedure;

                //Supply data to the parameters of stored proc
                cmd.Parameters.AddWithValue("@patient_id", patient_id);
                cmd.Parameters.AddWithValue("@patient_name", patient_name);
                cmd.Parameters.AddWithValue("@dob", dob);
                cmd.Parameters.AddWithValue("@aadhaar_id", aadhaar_id);
                cmd.Parameters.AddWithValue("@guardian_name", guardian_name);
                cmd.Parameters.AddWithValue("@blood_group", blood_group);
                cmd.Parameters.AddWithValue("@age", age);
                cmd.Parameters.AddWithValue("@gender", gender);
                cmd.Parameters.AddWithValue("@phone_number", phone_number);
                cmd.Parameters.AddWithValue("@emergency_Contact", emergency_Contact);
                cmd.Parameters.AddWithValue("@email_id", email_id);
                cmd.Parameters.AddWithValue("@address", address);
                cmd.Parameters.AddWithValue("@zipcode", zipcode);
                cmd.Parameters.AddWithValue("@city", city);
                cmd.Parameters.AddWithValue("@state", state);
                //Execute the stored proc
                int result = cmd.ExecuteNonQuery();

                return result; //either 1 or 0
            }
        }

        //UPDATE PATIENT
        public int update_patient_det(string patient_id, string patient_name, DateTime dob, double aadhaar_id, string guardian_name, string blood_group,
            int age, string gender, double phone_number, double emergency_Contact, string email_id, string address, double zipcode, string city, string state)
        {
            //ADO.NET FOR INSERT
            //(i)connection path to connect with SQL Server
            using (SqlConnection con = new SqlConnection(connection))
            {
                //open the connection
                con.Open();
                
                //Write SQL Command for Insert
                //Call Stored proc for insert
                SqlCommand cmd = new SqlCommand("update_patient", con);

                //What is insert_data?
                cmd.CommandType = CommandType.StoredProcedure;

                //Supply data to the parameters of stored proc
                cmd.Parameters.AddWithValue("@patient_id", patient_id);
                cmd.Parameters.AddWithValue("@patient_name", patient_name);
                cmd.Parameters.AddWithValue("@dob", dob);
                cmd.Parameters.AddWithValue("@aadhaar_id", aadhaar_id);
                cmd.Parameters.AddWithValue("@guardian_name", guardian_name);
                cmd.Parameters.AddWithValue("@blood_group", blood_group);
                cmd.Parameters.AddWithValue("@age", age);
                cmd.Parameters.AddWithValue("@gender", gender);
                cmd.Parameters.AddWithValue("@phone_number", phone_number);
                cmd.Parameters.AddWithValue("@emergency_Contact", emergency_Contact);
                cmd.Parameters.AddWithValue("@email_id", email_id);
                cmd.Parameters.AddWithValue("@address", address);
                cmd.Parameters.AddWithValue("@zipcode", zipcode);
                cmd.Parameters.AddWithValue("@city", city);
                cmd.Parameters.AddWithValue("@state", state);
                //Execute the stored proc
                int result = cmd.ExecuteNonQuery();

                return result; //either 1 or 0
            }
        }

   public DataTable login_data(string username, string password)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("login_user_insert", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@user_id", username);
                cmd.Parameters.AddWithValue("@pass", password);
                //Call all records present in the table through data adapter
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                
                //Create temporary storage location to store the data on client side
                DataSet ds = new DataSet();
                //Fill dataset with records that you have extracted via data adapter
                //Data Adapter uses Fill() method to insert all the extracted
                //data inside data set
                da.Fill(ds);
                DataTable dt = ds.Tables[0]; //1 Row will be extracted
                //if credentials matches
                return dt;
            }
        }

   public DataTable login_doctor(string username, string password)
   {
       using (SqlConnection con = new SqlConnection(connection))
       {
           con.Open();
           SqlCommand cmd = new SqlCommand("doctor_login", con);
           cmd.CommandType = CommandType.StoredProcedure;

           cmd.Parameters.AddWithValue("@doctor_id", username);
           cmd.Parameters.AddWithValue("@pass", password);
           //Call all records present in the table through data adapter
           SqlDataAdapter da = new SqlDataAdapter(cmd);
           DataTable dt = new DataTable();
           da.Fill(dt);
           return dt;
       }
   }

   public DataTable display_patient_data(string id)
   {
       using (SqlConnection con = new SqlConnection(connection))
       {
           con.Open();
           SqlCommand cmd = new SqlCommand("display_patient", con);
           cmd.CommandType = CommandType.StoredProcedure;

           cmd.Parameters.AddWithValue("@patient_id", id);
          
           //Call all records present in the table through data adapter
           SqlDataAdapter da = new SqlDataAdapter(cmd);

           DataTable dt = new DataTable();
           da.Fill(dt);
           return dt;
          
       }
   }

   public DataTable display_doctor_data(string id)
   {
       using (SqlConnection con = new SqlConnection(connection))
       {
           con.Open();
           SqlCommand cmd = new SqlCommand("display_doctor", con);
           cmd.CommandType = CommandType.StoredProcedure;

           cmd.Parameters.AddWithValue("@doctor_id", id);

           //Call all records present in the table through data adapter
           SqlDataAdapter da = new SqlDataAdapter(cmd);

           DataTable dt = new DataTable();
           da.Fill(dt);
           return dt;

       }
   }


   public DataTable assign_disease(string symptom)
   {
       using (SqlConnection con = new SqlConnection(connection))
       {
           con.Open();
           SqlCommand cmd = new SqlCommand("disease_specialisation", con);
           cmd.CommandType = CommandType.StoredProcedure;

           cmd.Parameters.AddWithValue("@symptom_name",symptom);

           //Call all records present in the table through data adapter
           SqlDataAdapter da = new SqlDataAdapter(cmd);

           DataTable dt = new DataTable();
           da.Fill(dt);
           return dt;

       }
   }

   

  


        //retrieving values for appointment 

   public DataTable  display_appointment(string id,string visiting_date)
   {
       using (SqlConnection con = new SqlConnection(connection))
       {
           con.Open();
           SqlCommand cmd = new SqlCommand("retrieve_assign_doctor", con);
           cmd.CommandType = CommandType.StoredProcedure;

           cmd.Parameters.AddWithValue("@patient_id", id);
           cmd.Parameters.AddWithValue("@visiting_date", visiting_date);

           //Call all records present in the table through data adapter
           SqlDataAdapter da = new SqlDataAdapter(cmd);

           DataTable dt = new DataTable();
           da.Fill(dt);
           return dt;
       }
   }

   //view doctor
   public DataTable select_doctor(string id)
   {
       using (SqlConnection con = new SqlConnection(connection))
       {
           con.Open();
           SqlCommand cmd = new SqlCommand("view_doctor", con);
           cmd.CommandType = CommandType.StoredProcedure;

           cmd.Parameters.AddWithValue("@doctor_id", id);

           //Call all records present in the table through data adapter
           SqlDataAdapter da = new SqlDataAdapter(cmd);

           DataTable dt = new DataTable();
           da.Fill(dt);
           return dt;
       }
   }

   public int insert_assign_doctor(string visiting_date,string patient_id,string disease_name,string symptoms_description,string room)
   {
       //ADO.NET FOR INSERT
       //(i)connection path to connect with SQL Server
       using (SqlConnection con = new SqlConnection(connection))
       {
           //open the connection
           con.Open();

           //Write SQL Command for Insert
           //Call Stored proc for insert
           SqlCommand cmd = new SqlCommand("insert_assign_doctor", con);

           //What is insert_data?
           cmd.CommandType = CommandType.StoredProcedure;
           DateTime dt = DateTime.ParseExact(visiting_date,"yyyy-MM-dd",null);
           //Supply data to the parameters of stored proc
           cmd.Parameters.AddWithValue("@visiting_date",dt);
           cmd.Parameters.AddWithValue("@patient_id", patient_id);
           cmd.Parameters.AddWithValue("@disease_name", disease_name);
           cmd.Parameters.AddWithValue("@symptoms_description", symptoms_description);
           cmd.Parameters.AddWithValue("@room", room);
           
           //Execute the stored proc
           int result = cmd.ExecuteNonQuery();

           return result; //either 1 or 0
       }

   }
       

        //doctor registration

   public int doctor_registration(string doctor_id, string doctor_password, string doctor_name, DateTime dob, double aadhaar_id, string blood_group,
        string gender, double phone_number, double emergency_Contact, string email_id, string specialisation, string address, double zipcode, string city, string state, string visiting_hours_start, string visiting_hours_end, int room_no)
   {
       //ADO.NET FOR INSERT
       //(i)connection path to connect with SQL Server
       using (SqlConnection con = new SqlConnection(connection))
       {
           //open the connection
           con.Open();

           //Write SQL Command for Insert
           //Call Stored proc for insert
           SqlCommand cmd = new SqlCommand("insert_data", con);

           //What is insert_data?
           cmd.CommandType = CommandType.StoredProcedure;

           //Supply data to the parameters of stored proc
           cmd.Parameters.AddWithValue("@doctor_id", doctor_id);
           cmd.Parameters.AddWithValue("@doctor_password", doctor_password);
           cmd.Parameters.AddWithValue("@doctor_name", doctor_name);
           cmd.Parameters.AddWithValue("@dob", dob);
           cmd.Parameters.AddWithValue("@aadhaar_id", aadhaar_id);
           cmd.Parameters.AddWithValue("@blood_group", blood_group);
           cmd.Parameters.AddWithValue("@gender", gender);
           cmd.Parameters.AddWithValue("@phone_number", phone_number);
           cmd.Parameters.AddWithValue("@emergency_Contact", emergency_Contact);
           cmd.Parameters.AddWithValue("@email_id", email_id);
           cmd.Parameters.AddWithValue("@specialisation", specialisation);
           cmd.Parameters.AddWithValue("@address", address);
           cmd.Parameters.AddWithValue("@zipcode", zipcode);
           cmd.Parameters.AddWithValue("@city", city);
           cmd.Parameters.AddWithValue("@state", state);
           cmd.Parameters.AddWithValue("@visiting_hours_start", visiting_hours_start);
           cmd.Parameters.AddWithValue("@visiting_hours_end", visiting_hours_end);
           cmd.Parameters.AddWithValue("@room_no", room_no);
           //Execute the stored proc
           int result = cmd.ExecuteNonQuery();

           return result; //either 1 or 0
       }

   }

   public int doctor_update(string doctor_id, string doctor_password, string doctor_name, DateTime dob, double aadhaar_id, string blood_group,
  string gender, double phone_number, double emergency_Contact, string email_id, string specialisation, string address, double zipcode, string city, string state, string visiting_hours_start, string visiting_hours_end, int room_no)
   {
       //ADO.NET FOR INSERT
       //(i)connection path to connect with SQL Server
       using (SqlConnection con = new SqlConnection(connection))
       {
           //open the connection
           con.Open();

           //Write SQL Command for Insert
           //Call Stored proc for insert
           SqlCommand cmd = new SqlCommand("update_doctor", con);

           //What is insert_data?
           cmd.CommandType = CommandType.StoredProcedure;

           //Supply data to the parameters of stored proc
           cmd.Parameters.AddWithValue("@doctor_id", doctor_id);
           cmd.Parameters.AddWithValue("@doctor_password", doctor_password);
           cmd.Parameters.AddWithValue("@doctor_name", doctor_name);
           cmd.Parameters.AddWithValue("@dob", dob);
           cmd.Parameters.AddWithValue("@aadhaar_id", aadhaar_id);
           cmd.Parameters.AddWithValue("@blood_group", blood_group);
           cmd.Parameters.AddWithValue("@gender", gender);
           cmd.Parameters.AddWithValue("@phone_number", phone_number);
           cmd.Parameters.AddWithValue("@emergency_Contact", emergency_Contact);
           cmd.Parameters.AddWithValue("@email_id", email_id);
           cmd.Parameters.AddWithValue("@specialisation", specialisation);
           cmd.Parameters.AddWithValue("@address", address);
           cmd.Parameters.AddWithValue("@zipcode", zipcode);
           cmd.Parameters.AddWithValue("@city", city);
           cmd.Parameters.AddWithValue("@state", state);
           cmd.Parameters.AddWithValue("@visiting_hours_start", visiting_hours_start);
           cmd.Parameters.AddWithValue("@visiting_hours_end", visiting_hours_end);
           cmd.Parameters.AddWithValue("@room_no", room_no);
           //Execute the stored proc
           int result = cmd.ExecuteNonQuery();

           return result; //either 1 or 0
       }

   }


   public int delete_patient_DAL(string patient_id)
   {
       //ADO.NET FOR INSERT
       //(i)connection path to connect with SQL Server
       using (SqlConnection con = new SqlConnection(connection))
       {
           //open the connection
           con.Open();

           //Write SQL Command for Insert
           //Call Stored proc for insert
           SqlCommand cmd = new SqlCommand("delete_patient", con);

           //What is insert_data?
           cmd.CommandType = CommandType.StoredProcedure;

           //Supply data to the parameters of stored proc
           cmd.Parameters.AddWithValue("@patient_id", patient_id);
           //Execute the stored proc
           int result = cmd.ExecuteNonQuery();

           return result; //either 1 or 0
       }
   }



   public int delete_doctor_DAL(string doctor_id)
   {
       //ADO.NET FOR INSERT
       //(i)connection path to connect with SQL Server
       using (SqlConnection con = new SqlConnection(connection))
       {
           //open the connection
           con.Open();

           //Write SQL Command for Insert
           //Call Stored proc for insert
           SqlCommand cmd = new SqlCommand("delete_doctor", con);

           //What is insert_data?
           cmd.CommandType = CommandType.StoredProcedure;

           //Supply data to the parameters of stored proc
           cmd.Parameters.AddWithValue("@doctor_id", doctor_id);
           //Execute the stored proc
           int result = cmd.ExecuteNonQuery();

           return result; //either 1 or 0
       }
   }


   public DataTable display_medication(string id)
   {
       using (SqlConnection con = new SqlConnection(connection))
       {
           con.Open();
           SqlCommand cmd = new SqlCommand("retrieve_assign_doctor_medication", con);
           cmd.CommandType = CommandType.StoredProcedure;

           cmd.Parameters.AddWithValue("@patient_id", id);


           //Call all records present in the table through data adapter
           SqlDataAdapter da = new SqlDataAdapter(cmd);

           DataTable dt = new DataTable();
           da.Fill(dt);
           return dt;
       }
   }


   public int assign_doctor_medication(string visiting_date, string patient_id, string test_name, string test_time, string test_room)
   {
       using (SqlConnection con = new SqlConnection(connection))
       {
           //open the connection
           con.Open();

           //Write SQL Command for Insert
           //Call Stored proc for insert
           SqlCommand cmd = new SqlCommand("AssignDoctor_medication", con);

           //What is insert_data?
           cmd.CommandType = CommandType.StoredProcedure;
           DateTime dt = Convert.ToDateTime(visiting_date);
           DateTime test_dt = DateTime.ParseExact(test_time, "yyyy-MM-dd", null);
           //Supply data to the parameters of stored proc
           cmd.Parameters.AddWithValue("@visiting_date", dt);
           cmd.Parameters.AddWithValue("@patient_id", patient_id);
           cmd.Parameters.AddWithValue("@test_name", test_name);
           cmd.Parameters.AddWithValue("@test_time", test_dt);
           cmd.Parameters.AddWithValue("@test_room", test_room);

           //Execute the stored proc
           int result = cmd.ExecuteNonQuery();

           return result; //either 1 or 0
       }


   }

   public int assign_doctor_medication_medicine(string visiting_date, string patient_id, string medicine_name, int no_of_doses, int no_of_days)
   {

       using (SqlConnection con = new SqlConnection(connection))
       {
           //open the connection
           con.Open();

           //Write SQL Command for Insert
           //Call Stored proc for insert
           SqlCommand cmd = new SqlCommand("AssignDoctor_medication_medicines", con);

           //What is insert_data?
           cmd.CommandType = CommandType.StoredProcedure;
           DateTime dt = Convert.ToDateTime(visiting_date);

           //Supply data to the parameters of stored proc
           cmd.Parameters.AddWithValue("@visiting_date", dt);
           cmd.Parameters.AddWithValue("@patient_id", patient_id);
           cmd.Parameters.AddWithValue("@medicine_name", medicine_name);
           cmd.Parameters.AddWithValue("@no_of_doses", no_of_doses);
           cmd.Parameters.AddWithValue("@no_of_days", no_of_days);

           //Execute the stored proc
           int result = cmd.ExecuteNonQuery();

           return result; //either 1 or 0
       }


   }





    }
}
